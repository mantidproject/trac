//----------------------------------------------------------------------
// Includes
//----------------------------------------------------------------------
#include "Muon_GausOsc.h"
#include <cmath>

namespace Mantid
{
namespace CurveFitting
{

using namespace Kernel;
using namespace API;

DECLARE_FUNCTION(Muon_GausOsc)

void Muon_GausOsc::init()
{
  declareParameter("A", 0.2);
  declareParameter("G", 0.2);
  declareParameter("frequency", 0.5);
  declareParameter("phi", 0.0);
}


void Muon_GausOsc::functionLocal(double* out, const double* xValues, const size_t nData)const
{
    const double& A = getParameter("A");
    const double& G = getParameter("G");
	const double& f = getParameter("frequency");
	const double& phi = getParameter("phi");
  
 
   for (int i = 0; i < nData; i++) {
       // double diff=xValues[i]-peakCentre;
	   // double e=pow(gs*xValues[i],2.0);
        out[i] = A*exp(-pow(G*xValues[i],2)/2)*cos(2*3.1415927*f*xValues[i]+phi);
    }
}
void Muon_GausOsc::functionDerivLocal(API::Jacobian* out, const double* xValues, const size_t nData)
{
  calNumericalDeriv(out, xValues, nData);
}




} // namespace CurveFitting
} // namespace Mantid
