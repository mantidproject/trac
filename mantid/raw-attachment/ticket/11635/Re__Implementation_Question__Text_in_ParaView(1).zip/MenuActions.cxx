#include "MenuActions.h"

#include <QApplication>
#include <QStyle>

#include "pqActiveObjects.h"
#include "pqApplicationCore.h"
#include "pqDataRepresentation.h"
#include "pqPipelineSource.h"
#include "pqRenderView.h"
#include "pqServerManagerModel.h"
#include "vtkNew.h"
#include "vtkSMParaViewPipelineController.h"
#include "vtkSMPropertyHelper.h"
#include "vtkSMProxy.h"
#include "vtkSMSessionProxyManager.h"

#include <map>
#include <algorithm>

class MenuActions::CInternals
{
  typedef std::map<std::pair<vtkSMProxy*, vtkSMProxy*>, vtkWeakPointer<vtkSMProxy> > LabelRepresentationsMapType;
  LabelRepresentationsMapType LabelRepresentationsMap;
public:
  vtkSMProxy* getLabelRepresentation(
    vtkSMProxy* renderView, vtkSMProxy* source, bool create_new_if_needed=false)
    {
    Q_ASSERT(renderView != NULL && source != NULL);

    LabelRepresentationsMapType::iterator iter = this->LabelRepresentationsMap.find(
      std::pair<vtkSMProxy*, vtkSMProxy*>(renderView, source));
    if (iter != this->LabelRepresentationsMap.end())
      {
      return iter->second.GetPointer();
      }

    if (create_new_if_needed)
      {
      vtkSMSessionProxyManager* pxm = source->GetSessionProxyManager();
      vtkSMProxy* labelRepresentation = pxm->NewProxy("representations", "DataLabelRepresentation");

      //vtkNew<vtkSMParaViewPipelineController> controller;
      //controller->PreInitializeProxy(labelRepresentation);
      vtkSMPropertyHelper(labelRepresentation, "Input").Set(source);
      vtkSMPropertyHelper(labelRepresentation, "PointLabelMode").Set("IDs");
      vtkSMPropertyHelper(labelRepresentation, "PointLabelVisibility").Set(1);
      //controller->PostInitializeProxy(labelRepresentation);
      labelRepresentation->UpdateVTKObjects();

      //controller->RegisterRepresentationProxy(labelRepresentation);

      vtkSMPropertyHelper(renderView, "Representations").Add(labelRepresentation);
      renderView->UpdateVTKObjects();

      this->LabelRepresentationsMap[std::pair<vtkSMProxy*, vtkSMProxy*>(renderView, source)]  = labelRepresentation;
      labelRepresentation->FastDelete();
      return labelRepresentation;
      }
    return NULL;
    }

  void removeSource(vtkSMProxy* source)
    {
    for (LabelRepresentationsMapType::iterator iter = this->LabelRepresentationsMap.begin();
      iter != this->LabelRepresentationsMap.end();)
      {
      if (iter->first.second == source)
        {
        LabelRepresentationsMapType::iterator newIter = iter;
        ++newIter;

        vtkSMPropertyHelper(iter->first.first, "Representations").Remove(iter->second.GetPointer());
        iter->first.first->UpdateVTKObjects();

        this->LabelRepresentationsMap.erase(iter);
        iter = newIter;
        }
      else
        {
        ++iter;
        }
      }
    }

  void removeView(vtkSMProxy* view)
    {
    for (LabelRepresentationsMapType::iterator iter = this->LabelRepresentationsMap.begin();
      iter != this->LabelRepresentationsMap.end();)
      {
      if (iter->first.first == view)
        {
        LabelRepresentationsMapType::iterator toErase = iter;
        ++iter;
        this->LabelRepresentationsMap.erase(toErase);
        }
      else
        {
        ++iter;
        }
      }
    }
};

//-----------------------------------------------------------------------------
MenuActions::MenuActions(QObject* p)
  : QActionGroup(p),
  Internals(new MenuActions::CInternals())
{
  QIcon icon = qApp->style()->standardIcon(QStyle::SP_MessageBoxCritical);

  QAction* a = this->addAction(new QAction(icon, "Toggle Label Visibility", this));
  QObject::connect(a, SIGNAL(triggered(bool)), this, SLOT(onAction()));


  pqServerManagerModel* smmodel = pqApplicationCore::instance()->getServerManagerModel();
  this->connect(smmodel, SIGNAL(sourceRemoved(pqPipelineSource*)), SLOT(sourceRemoved(pqPipelineSource*)));
  this->connect(smmodel, SIGNAL(viewRemoved(pqView*)), SLOT(viewRemoved(pqView*)));
}

//-----------------------------------------------------------------------------
MenuActions::~MenuActions()
{
}

//-----------------------------------------------------------------------------
void MenuActions::onAction()
{
  this->setLabelVisibility(!this->labelVisibility());
}

//-----------------------------------------------------------------------------
void MenuActions::setLabelVisibility(bool visible,
  pqView* _view, pqPipelineSource* _source)
{
  pqPipelineSource* source = _source? _source : pqActiveObjects::instance().activeSource();
  pqView* view = _view? _view : pqActiveObjects::instance().activeView();
  if (source == NULL || qobject_cast<pqRenderView*>(view) == NULL)
    {
    return;
    }

  this->connect(source, SIGNAL(visibilityChanged(pqPipelineSource*, pqDataRepresentation*)),
    SLOT(sourceVisibilityChanged(pqPipelineSource*, pqDataRepresentation*)),
    Qt::UniqueConnection);

  vtkSMProxy* labelRepresentations = this->Internals->getLabelRepresentation(
    view->getProxy(), source->getProxy(), /*create_new_if_needed=*/ visible);
  if (labelRepresentations)
    {
    vtkSMPropertyHelper(labelRepresentations, "PointLabelVisibility").Set(visible? 1 :0);
    labelRepresentations->UpdateVTKObjects();
    view->render();
    }
}

//-----------------------------------------------------------------------------
bool MenuActions::labelVisibility(pqView* _view, pqPipelineSource* _source) const
{
  pqPipelineSource* source = _source? _source : pqActiveObjects::instance().activeSource();
  pqView* view = _view? _view : pqActiveObjects::instance().activeView();
  if (source == NULL || qobject_cast<pqRenderView*>(view) == NULL)
    {
    return false;
    }
  if (vtkSMProxy* labelRepresentations = this->Internals->getLabelRepresentation(
      view->getProxy(), source->getProxy(), false))
    {
    return vtkSMPropertyHelper(labelRepresentations, "PointLabelVisibility").GetAsInt() == 1;
    }
  return false;
}

//-----------------------------------------------------------------------------
void MenuActions::sourceVisibilityChanged(pqPipelineSource* source, pqDataRepresentation* repr)
{
  Q_ASSERT(source && repr);

  if (repr->getView() && this->Internals->getLabelRepresentation(
      repr->getView()->getProxy(), source->getProxy(), false))
    {
    this->setLabelVisibility(repr->isVisible(), repr->getView(), source);
    }
}

//-----------------------------------------------------------------------------
void MenuActions::sourceRemoved(pqPipelineSource* source)
{
  this->Internals->removeSource(source->getProxy());
}

//-----------------------------------------------------------------------------
void MenuActions::viewRemoved(pqView* view)
{
  this->Internals->removeView(view->getProxy());
}
