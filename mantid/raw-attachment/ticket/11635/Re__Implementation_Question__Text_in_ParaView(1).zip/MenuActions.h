#ifndef __MenuActions_h
#define __MenuActions_h

#include <QActionGroup>
#include <QScopedPointer>

class pqPipelineSource;
class pqDataRepresentation;
class pqView;

class MenuActions : public QActionGroup
{
  Q_OBJECT
public:
  MenuActions(QObject* p);
  ~MenuActions();

public slots:
  void onAction();

private slots:
  void sourceVisibilityChanged(pqPipelineSource*, pqDataRepresentation*);
  void sourceRemoved(pqPipelineSource*);
  void viewRemoved(pqView*);

private:
  /// Set ID label visibility in active view for active source.
  void setLabelVisibility(bool visible, pqView* view=NULL, pqPipelineSource* source=NULL);

  /// Get the label visibility for active source in active view.
  bool labelVisibility(pqView* view=NULL, pqPipelineSource* source=NULL) const;

private:
  class CInternals;
  QScopedPointer<CInternals> Internals;
};

#endif
