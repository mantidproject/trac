Sample Plugin
=============

This plugin add a menu action (under **Custom** menu) to label the active
dataset in the active view.

Caveats
-------

This is just a quick hack to demonstrate how one can add a **DataLabelRepresentation** to
the view to label a dataset, not really intended for production use.
