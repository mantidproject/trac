from isis_reflgui import quick

LoadISISNexus(Filename='13463', OutputWorkspace='13463')
LoadISISNexus(Filename='13464', OutputWorkspace='13464')
LoadISISNexus(Filename='13460', OutputWorkspace='13460')

transrun = '13463,13464'
runno = '13460'
angle = 0.7
config['default.instrument'] = 'INTER'
quick.quick(runno, trans=transrun, theta=angle)  