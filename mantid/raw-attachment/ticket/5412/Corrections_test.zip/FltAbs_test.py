# Algorithm to start Bayes programs
from MantidFramework import *
from IndirectAbsCor import *

sname = 'irs26176_graphite002_red'
workdir = config['defaultsave.directory']
spath = os.path.join(workdir, sname+'.nxs')		# path name for sample nxs file
LoadNexusProcessed(Filename=spath, OutputWorkspace=sname)

beam = ''
size = [0.1, 0.01, 0.01]
density = [0.1, 0.1, 0.1]
sigs = [5.0, 0.1, 0.1]
siga = [0.0, 5.0, 5.0]
avar = 45.0
verbOp = True
saveOp = False
workspaces = AbsRun(sname, 'flt', beam, 2, size, density,
	sigs, siga, avar, verbOp, saveOp)
