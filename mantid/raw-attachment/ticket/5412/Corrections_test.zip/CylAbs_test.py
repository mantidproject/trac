# Algorithm to start Bayes programs
from MantidFramework import *
from IndirectAbsCor import *

sname = 'irs26176_graphite002_red'
workdir = config['defaultsave.directory']
spath = os.path.join(workdir, sname+'.nxs')		# path name for sample nxs file
LoadNexusProcessed(Filename=spath, OutputWorkspace=sname)

beam = [3.0, 1.0, -1.0, 2.0, -2.0, 0.0, 3.0, 0.0, 3.0]
size = [0.2, 0.25, 0.26, 0.0]
density = [0.1, 0.1, 0.1]
sigs = [5.0, 0.1, 0.1]
siga = [0.0, 5.0, 5.0]
avar = 0.002
verbOp = True
saveOp = False
workspaces = AbsRun(sname, 'cyl', beam, 2, size, density,
	sigs, siga, avar, verbOp, saveOp)
