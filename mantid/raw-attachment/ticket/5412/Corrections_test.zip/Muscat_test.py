# Algorithm to start Bayes programs
from MantidFramework import *
from IndirectImport import run_f2py_compatibility_test, is_supported_f2py_platform

if is_supported_f2py_platform():
	import IndirectMuscat as Main

run_f2py_compatibility_test()

sname = 'irs26176_graphite002'
neut = [1000, 1000, 12345, 67890, 2]
beam = [0.1, 2.0, 3.0, 45.0]
sam = [300.0, 0.1, 0.1, 5.0]
grid = [10, 0.2, 100, 2.0]
coeff = [0., 0., 50., 0., 0.]
kr1 = 1
verbOp = False
plotOp = 'None'
saveOp = False
Main.MuscatFuncStart(sname,'Flat',neut,beam,sam,grid,'Poly',coeff,kr1,verbOp,plotOp,saveOp)
