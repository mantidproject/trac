# Algorithm to start IN16reduce
from mantid.simpleapi import *
from mantid.kernel import StringListValidator, StringMandatoryValidator
from mantid.api import PythonAlgorithm, AlgorithmFactory
from mantid import config, logger, mtd
import sys, os.path, math

workdir = config['defaultsave.directory']
instr = 'IN16B'
run = '034745'
ana = 'silicon'
refl = '111'
map = 'user'
mirror = True
Verbose = True
Save = True
Plot = False

run_name = 'IN16B_'+run
raw_name = run_name+'_'+ana+refl+'_raw'
run_path = os.path.join(workdir, run+'.nxs')		# path name for sample nxs file
LoadILLIndirect(FileName=run_path, OutputWorkspace=raw_name)
AddSampleLog(Workspace=raw_name, LogName="mirror_sense", LogType="String", LogText=str(mirror))
if Verbose:
	logger.notice('Nxs file : '+run_path)
from IndirectNeutron import ILLindirect
ILLindirect(raw_name,instr,ana,refl,map,Verbose,Plot,Save)
