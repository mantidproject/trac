#Force for ILL backscattering raw
#
from IndirectImport import *
from mantid.simpleapi import *
from mantid import config, logger, mtd, FileFinder
from mantid.kernel import V3D
import sys, math, os.path, numpy as np
from IndirectCommon import StartTime, EndTime, ExtractFloat, ExtractInt
mp = import_mantidplot()

#  Routines for Ascii file of raw data

def Iblock(a,first):                                 #read Ascii block of Integers
	line1 = a[first]
	line2 = a[first+1]
	val = ExtractInt(line2)
	numb = val[0]
	lines=numb/10
	last = numb-10*lines
	if line1.startswith('I'):
		error = ''
	else:
		error = 'NOT an I block starting at line ' +str(first)
		logger.notice('ERROR *** ' + error)
		sys.exit(error)
	ival = []
	for m in range(0, lines):
		mm = first+2+m
		val = ExtractInt(a[mm])
		for n in range(0, 10):
			ival.append(val[n])
	mm += 1
	val = ExtractInt(a[mm])
	for n in range(0, last):
		ival.append(val[n])
	mm += 1
	return mm,ival                                       #values as list

def Fblock(a,first):                                 #read Ascii block of Floats 
	line1 = a[first]
	line2 = a[first+1]
	val = ExtractInt(line2)
	numb = val[0]
	lines=numb/5
	last = numb-5*lines
	if line1.startswith('F'):
		error= ''
	else:
		error = 'NOT an F block starting at line ' +str(first)
		logger.notice('ERROR *** ' + error)
		sys.exit(error)
	fval = []
	for m in range(0, lines): 
		mm = first+2+m
		val = ExtractFloat(a[mm])
		for n in range(0, 5):
			fval.append(val[n])
	mm += 1
	val = ExtractFloat(a[mm])
	for n in range(0, last):
		fval.append(val[n])
	mm += 1
	return mm,fval                                       #values as list

def ReadIbackGroup(a,first):                           #read Ascii block of spectrum values
	x = []
	y = []
	e = []
	next = first
	line1 = a[next]
	next += 1
	val = ExtractInt(a[next])
	n1 = val[0]
	ngrp = val[2]
	if line1.startswith('S'):
		error = ''
	else:
		error = 'NOT an S block starting at line ' +str(first)
		logger.notice('ERROR *** ' + error)
		sys.exit(error)
	next += 1
	next,Ival = Iblock(a,next)
	for m in range(0, len(Ival)): 
		x.append(float(m))
		yy = float(Ival[m])
		y.append(yy)
		ee = math.sqrt(yy)
		e.append(ee)
	return next,x,y,e                                #values of x,y,e as lists

# Get the path to the file
# checks if we already know the path, else
# returns searches of the file based on run number and instrument
def getFilePath(run,ext,instr):
	path = None
	fname = None
	if(os.path.isfile(run)): 
		#using full file path 
		path = run
		#base name less extension
		base = os.path.basename(path)
		fname = os.path.splitext(base)[0]
	else:
		#using run number
		path = FileFinder.getFullPath(instr + "_" + run + ext)
		fname = instr + "_" + run

	if path:
		return path, fname
	else:
		error = 'ERROR *** Could not find ' + ext + ' file: ' + fname
		sys.exit(error)

# Load an ascii/inx file
def loadFile(path):
	try:
		handle = open(path, 'r')
		asc = []
		for line in handle:
			line = line.rstrip()
			asc.append(line)
		handle.close()

		return asc
	except:
		error = 'ERROR *** Could not load ' + path
		sys.exit(error)

def IbackStart(instr,run,ana,refl,rejectZ,useM,mapPath,Verbose,Plot,Save):      #Ascii start routine
	StartTime('Iback')
	workdir = config['defaultsave.directory']

	path, fname = getFilePath(run,'.asc',instr)

	if Verbose:
		logger.notice('Reading file : ' + path)

	asc = loadFile(path)
	lasc = len(asc)

# raw head
	text = asc[1]
	run = text[:8]
	first = 5
	next,Ival = Iblock(asc,first)
	next += 2
	title = asc[next]    # title line
	next += 1
	text = asc[next]   # user line
	user = text[20:32]
	time = text[40:50]
	next += 6           # 5 lines of text
# back head1
	next,Fval = Fblock(asc,next)
	if instr == 'IN10':
		freq = Fval[89]
	if instr == 'IN16':
		freq = Fval[2]
		amp = Fval[3]
		wave = Fval[69]
		Ef = 81.787/(4.0*wave*wave)
		npt = int(Fval[6])
		nsp = int(Fval[7])
# back head2
	next,Fval = Fblock(asc,next)
	k0 = 4.0*math.pi/wave
	d2r = math.pi/180.0
	theta = []
	Q = []
	for m in range(0, nsp): 
		theta.append(Fval[m])
# raw spectra
	val = ExtractInt(asc[next+3])
	npt = val[0]
	lgrp=5+npt/10
	val = ExtractInt(asc[next+1])
	if instr == 'IN10':
		nsp = int(val[2])
	if Verbose:
		logger.notice('Number of spectra : ' + str(nsp))
# read monitor
	nmon = next+nsp*lgrp
	nm,xm,ym,em = ReadIbackGroup(asc,nmon)
# monitor calcs
	imin = 0
	ymax = 0
	for m in range(0, 20):
		if ym[m] > ymax:
			imin=m
			ymax=ym[m]
	npt = len(ym)
	imax = npt
	ymax = 0
	for m in range(npt-1, npt-20, -1):
		if ym[m] > ymax:
			imax=m
			ymax=ym[m]
	new=imax-imin
	imid=new/2+1
	if instr == 'IN10':
		DRV=18.706							# fast drive
		vmax=freq*DRV
	if instr == 'IN16':
		vmax=1.2992581918414711e-4*freq*amp*2.0/wave 	#max energy
	dele=2.0*vmax/new
	xMon = []
	yOut = []
	eOut = []
	for m in range(0, new+1):
		xe = (m-imid)*dele
		mm = m+imin
		xMon.append(xe)
		yOut.append(ym[mm]/100.0)
		eOut.append(em[mm]/10.0)
	xMon.append(2*xMon[new-1]-xMon[new-2])
	monWS = '__Mon'
	CreateWorkspace(OutputWorkspace=monWS, DataX=xMon, DataY=yOut, DataE=eOut,
		Nspec=1, UnitX='Energy')
#
	Qaxis = ''
	xDat = []
	yDat = []
	eDat = []
	tot = []
	for n in range(0, nsp):
		next,xd,yd,ed = ReadIbackGroup(asc,next)
		tot.append(sum(yd))
		if Verbose:
			logger.notice('Spectrum ' + str(n+1) +' at angle '+ str(theta[n])+
				' ; Total counts = '+str(sum(yd)))
		for m in range(0, new+1):
			mm = m+imin
			xDat.append(xMon[m])
			yDat.append(yd[mm])
			eDat.append(ed[mm])
		if n != 0:
			Qaxis += ','
		xDat.append(2*xDat[new-1]-xDat[new-2])
		Qaxis += str(theta[n])
	ascWS = fname +'_' +ana+refl +'_asc'
	outWS = fname +'_' +ana+refl +'_red'
	CreateWorkspace(OutputWorkspace=ascWS, DataX=xDat, DataY=yDat, DataE=eDat,
		Nspec=nsp, UnitX='Energy')
	Divide(LHSWorkspace=ascWS, RHSWorkspace=monWS, OutputWorkspace=ascWS,
		AllowDifferentNumberSpectra=True)
	DeleteWorkspace(monWS)								# delete monitor WS
	InstrParas(ascWS,instr,ana,refl)
	efixed = RunParas(ascWS,instr,run,title,Verbose)
	ChangeAngles(ascWS,instr,theta,Verbose)
	if useM:
		map = ReadMap(mapPath,Verbose)
		UseMap(ascWS,map,Verbose)
	if rejectZ:
		RejectZero(ascWS,tot,Verbose)
	if useM == False and rejectZ == False:
		CloneWorkspace(InputWorkspace=ascWS, OutputWorkspace=outWS)
	if Save:
		opath = os.path.join(workdir,outWS+'.nxs')
		SaveNexusProcessed(InputWorkspace=outWS, Filename=opath)
		if Verbose:
			logger.notice('Output file : ' + opath)
	if (Plot):
		plotForce(outWS,Plot)
	EndTime('Iback')

# Routines for Inx ascii file

def ReadInxGroup(asc,n,lgrp):                  # read ascii x,y,e
	x = []
	y = []
	e = []
	first = n*lgrp
	last = (n+1)*lgrp
	val = ExtractFloat(asc[first+2])
	Q = val[0]
	for m in range(first+4, last): 
		val = ExtractFloat(asc[m])
		x.append(val[0]/1000.0)
		y.append(val[1])
		e.append(val[2])
	npt = len(x)
	return Q,npt,x,y,e                                 #values of x,y,e as lists

def InxStart(instr,run,ana,refl,rejectZ,useM,mapPath,Verbose,Plot,Save):
	StartTime('Inx')
	workdir = config['defaultsave.directory']

	path, fname = getFilePath(run, '.inx', instr)

	if Verbose:
		logger.notice('Reading file : ' + path)

	asc = loadFile(path)
	lasc = len(asc)

	val = ExtractInt(asc[0])
	lgrp = int(val[0])
	ngrp = int(val[2])
	npt = int(val[7])
	title = asc[1]
	ltot = ngrp*lgrp
	if Verbose:
		logger.notice('Number of spectra : ' + str(ngrp))
	if ltot == lasc:
		error = ''
	else:
		error = 'file ' +filext+ ' should be ' +str(ltot)+ ' lines'
		logger.notice('ERROR *** ' + error)
		sys.exit(error)
	Qaxis = ''
	xDat = []
	yDat = []
	eDat = []
	ns = 0
	Q = []
	tot = []
	for m in range(0,ngrp):
		Qq,nd,xd,yd,ed = ReadInxGroup(asc,m,lgrp)
		tot.append(sum(yd))
		if Verbose:
			logger.notice('Spectrum ' + str(m+1) +' at Q= '+ str(Qq)+' ; Total counts = '+str(tot))
		if ns != 0:
			Qaxis += ','
		Qaxis += str(Qq)
		Q.append(Qq)
		for n in range(0,nd):
			xDat.append(xd[n])
			yDat.append(yd[n])
			eDat.append(ed[n])
		xDat.append(2*xd[nd-1]-xd[nd-2])
		ns += 1
	ascWS = fname +'_' +ana+refl +'_inx'
	outWS = fname +'_' +ana+refl +'_red'
	CreateWorkspace(OutputWorkspace=ascWS, DataX=xDat, DataY=yDat, DataE=eDat,
		Nspec=ns, UnitX='Energy')
	InstrParas(ascWS,instr,ana,refl)
	efixed = RunParas(ascWS,instr,run,title,Verbose)	
	pi4 = 4.0*math.pi
	wave=1.8*math.sqrt(25.2429/efixed)
	theta = []
	for n in range(0,ngrp):
		qw = wave*Q[n]/pi4
		ang = 2.0*math.degrees(math.asin(qw))
		theta.append(ang)
	ChangeAngles(ascWS,instr,theta,Verbose)
	if useM:
		map = ReadMap(mapPath,Verbose)
		UseMap(ascWS,map,Verbose)
	if rejectZ:
		RejectZero(ascWS,tot,Verbose)
	if useM == False and rejectZ == False:
		CloneWorkspace(InputWorkspace=ascWS, OutputWorkspace=outWS)
	if Save:
		opath = os.path.join(workdir,outWS+'.nxs')
		SaveNexusProcessed(InputWorkspace=outWS, Filename=opath)
		if Verbose:
			logger.notice('Output file : ' + opath)
	if (Plot):
		plotForce(outWS,Plot)
	EndTime('Inx')
	
# General routines

def RejectZero(inWS,tot,Verbose):
	nin = mtd[inWS].getNumberHistograms()                      # no. of hist/groups in sam
	nout = 0
	outWS = inWS[:-3]+'red'
	for n in range(0, nin):
		if tot[n] > 0:
			ExtractSingleSpectrum(InputWorkspace=inWS, OutputWorkspace='__tmp',
				WorkspaceIndex=n)
			if nout == 0:
				RenameWorkspace(InputWorkspace='__tmp', OutputWorkspace=outWS)
			else:
				ConjoinWorkspaces(InputWorkspace1=outWS, InputWorkspace2='__tmp',CheckOverlapping=False)
			nout += 1
		else:
			if Verbose:
				logger.notice('** spectrum '+str(n+1)+' rejected')

def ReadMap(path,Verbose):
	workdir = config['defaultsave.directory']

	asc = loadFile(path)

	lasc = len(asc)
	if Verbose:
		logger.notice('Map file : ' + path +' ; spectra = ' +str(lasc-1))
	val = ExtractInt(asc[0])
	numb = val[0]
	if (numb != (lasc-1)):
		error = 'Number of lines  not equal to number of spectra'
		logger.notice('ERROR *** ' + error)
		sys.exit(error)
	map = []
	for n in range(1,lasc):
		val = ExtractInt(asc[n])
		map.append(val[1])
	return map
		
def UseMap(inWS,map,Verbose):
	nin = mtd[inWS].getNumberHistograms()                      # no. of hist/groups in sam
	nout = 0
	outWS = inWS[:-3]+'red'
	for n in range(0, nin):
		if map[n] == 1:
			ExtractSingleSpectrum(InputWorkspace=inWS, OutputWorkspace='__tmp',
				WorkspaceIndex=n)
			if nout == 0:
				RenameWorkspace(InputWorkspace='__tmp', OutputWorkspace=outWS)
			else:
				ConjoinWorkspaces(InputWorkspace1=outWS, InputWorkspace2='__tmp',CheckOverlapping=False)
			nout += 1
			if Verbose:
				logger.notice('** spectrum '+str(n+1)+' mapped')
		else:
			if Verbose:
				logger.notice('** spectrum '+str(n+1)+' skipped')

def plotForce(inWS,Plot):
	if (Plot == 'Spectrum' or Plot == 'Both'):
		nHist = mtd[inWS].getNumberHistograms()
		if nHist > 10 :
			nHist = 10
		plot_list = []
		for i in range(0, nHist):
			plot_list.append(i)
		res_plot=mp.plotSpectrum(inWS,plot_list)
	if (Plot == 'Contour' or Plot == 'Both'):
		cont_plot=mp.importMatrixWorkspace(inWS).plotGraph2D()

def ChangeAngles(inWS,instr,theta,Verbose):
	workdir = config['defaultsave.directory']
	file = instr+'_angles.txt'
	path = os.path.join(workdir, file)
	if Verbose:
		logger.notice('Creating angles file : ' + path)
	handle = open(path, 'w')
	head = 'spectrum,theta'
	handle.write(head +" \n" )
	for n in range(0,len(theta)):
		handle.write(str(n+1) +'   '+ str(theta[n]) +"\n" )
		if Verbose:
			logger.notice('Spectrum ' +str(n+1)+ ' = '+str(theta[n]))
	handle.close()
	UpdateInstrumentFromFile(Workspace=inWS, Filename=path, MoveMonitors=False, IgnorePhi=False,
		AsciiHeader=head)

def InstrParas(ws,instr,ana,refl):
	idf_dir = config['instrumentDefinition.directory']
	idf = idf_dir + instr + '_Definition.xml'
	LoadInstrument(Workspace=ws, Filename=idf, RewriteSpectraMap=False)
	ipf = idf_dir + instr + '_' + ana + '_' + refl + '_Parameters.xml'
	LoadParameterFile(Workspace=ws, Filename=ipf)

def RunParas(ascWS,instr,run,title,Verbose):
	ws = mtd[ascWS]
	inst = ws.getInstrument()
	AddSampleLog(Workspace=ascWS, LogName="facility", LogType="String", LogText="ILL")
	ws.getRun()['run_number'] = run
	ws.getRun()['run_title'] = title
	efixed = inst.getNumberParameter('efixed-val')[0]
	if Verbose:
		facility = ws.getRun().getLogData('facility').value
		logger.notice('Facility is ' +facility)
		runNo = ws.getRun()['run_number'].value
		runTitle = ws.getRun()['run_title'].value.strip()
		logger.notice('Run : ' +runNo + ' ; Title : ' + runTitle)
		an = inst.getStringParameter('analyser')[0]
		ref = inst.getStringParameter('reflection')[0]
		logger.notice('Analyser : ' +an+ref +' with energy = ' + str(efixed))
	return efixed

# IN13 routines
# These routines are specific to loading data for the ILL IN13 instrument

def IN13Start(instr,run,ana,refl,rejectZ,useM,mapPath,Verbose,Plot,Save):      #Ascii start routine
	StartTime('IN13')
	samWS = IN13Read(instr,run,ana,refl,Verbose,Plot,Save)
	EndTime('IN13')

def IN13Read(instr,run,ana,refl,Verbose,Plot,Save):      #Ascii start routine
	workdir = config['defaultsave.directory']
	
	path, fname = getFilePath(run,'.asc', instr)

	if Verbose:
		logger.notice('Reading file : ' + path)

	asc = loadFile(path)
	lasc = len(asc)

# header block
	text = asc[1]
	run = text[:8]
	text = asc[4]    # run line
	instr = text[:4]
	time = text[14:33]   # user line
	next,Ival = Iblock(asc,5)
	nsubsp = Ival[0]
	nspec = Ival[153]-2
# text block
	text = asc[25]
	title = text[:20]
# para1 block
	next,Fval = Fblock(asc,32)
	ntemp = int(Fval[6])
	f1 = ntemp/10
	ltemp = int(f1)
	f2 = f1 -10*ltemp
	if f2 >= 0.:
		ltemp = ltemp +1
	wave = 2.0*Fval[81]
	if Verbose:
		logger.notice('No. sub-spectra : ' + str(nsubsp))
		logger.notice('No. spectra : ' + str(nspec))
		logger.notice('Scan type : ' + str(int(Fval[8]))+
			' ; Average energy : ' + str(Fval[9]))
		logger.notice('CaF2 lattice : ' + str(Fval[81])+
			' ; Graphite lattice : ' + str(Fval[82]))
		logger.notice('Wavelength : ' + str(wave))
		logger.notice('No. temperatures : ' + str(ntemp))
		logger.notice('No. temperature lines : ' + str(ltemp))
# para2 block
	next,Fval = Fblock(asc,next)
	angles = Fval[:nspec]
	if Verbose:
		logger.notice('Angles : ' + str(angles))
	lspec = 4 +ltemp
# monitors
	psd = next + (nspec+2048)*lspec
	l1m1 = psd + 1
	txt = asc[l1m1]
	l2m1 = l1m1 +3
	mon1 = ExtractFloat(asc[l2m1])
	if Verbose:
		logger.notice('Mon1 : Line '+str(l2m1)+' : ' + asc[l2m1])
# raw spectra
	first = next
	xDat = angles
	y2D = []
	e2D = []
	for n in range(0,nspec):
		ylist = []
		elist = []
		l1 = first + lspec*n + 1
		if Verbose:
			logger.notice('Line '+str(l1)+' : ' + asc[l1])
		for l in range(0,ltemp):
			l2 = l1 + 3 + l
			val = ExtractFloat(asc[l2])
			nval = len(val)
			for m in range(0,nval):
				ylist.append(val[m]/mon1[m])
				elist.append(math.sqrt(val[m])/mon1[m])
		y2D.append(ylist)
		e2D.append(elist)
# create WS
	npt = len(xDat)
	xDat.append(2*xDat[npt-1]-xDat[npt-2])
	ascWS = fname + '_' + ana + refl + '_ang'
	outWS = fname + '_' + ana + refl + '_q'
	xD = np.array(xDat)
	k0 = 4*math.pi/wave
	Q = []
	for n in range(0,nspec):
		if angles[n] >= 180.0:
			angles[n] = 360.0 - angles[n]
		theta = math.radians(angles[n]/2.)
		qq = k0*math.sin(theta)
		Q.append(qq)
	Qa = np.array(Q)
	sorted_indices=Qa.argsort()
	sorted_Q=Qa[sorted_indices]
	lxdq = len(sorted_Q)
	xlast = 2*sorted_Q[lxdq-1]-sorted_Q[lxdq-2]
	sorted_Q = np.append(sorted_Q,xlast)
	xDq = sorted_Q
	for m in range(0,nval):
		ylist = []
		elist = []
		for n in range(0,nspec):
			ylist.append(y2D[n][m])
			elist.append(e2D[n][m])
		y1D = np.array(ylist)
		e1D = np.array(elist)
		y1Dq = y1D[sorted_indices]
		e1Dq = e1D[sorted_indices]
		if m == 0:
			xData = xD
			yData = y1D
			eData = e1D
			xDq = sorted_Q
			yDq = y1Dq
			eDq = e1Dq
		else:
			xData = np.append(xData,xD)
			yData = np.append(yData,y1D)
			eData = np.append(eData,e1D)
			xDq = np.append(xDq,sorted_Q)
			yDq = np.append(yDq,y1Dq)
			eDq = np.append(eDq,e1Dq)
	CreateWorkspace(OutputWorkspace=ascWS, DataX=xData, DataY=yData, DataE=eData,
		Nspec=3, UnitX='MomentumTransfer')
	IN13Paras(ascWS,run,title,wave,Verbose)
	CreateWorkspace(OutputWorkspace=outWS, DataX=xDq, DataY=yDq, DataE=eDq,
		Nspec=3, UnitX='MomentumTransfer')
	IN13Paras(outWS,run,title,wave,Verbose)
	if Save:
		opath = os.path.join(workdir,outWS+'.nxs')
		SaveNexusProcessed(InputWorkspace=outWS, Filename=opath)
		if Verbose:
			logger.notice('Output file : ' + opath)
	if (Plot != 'None'):
		plotForce(outWS,Plot)
	return outWS

def IN13Paras(ascWS,run,title,wave,Verbose):
	ws = mtd[ascWS]
	AddSampleLog(Workspace=ascWS, LogName="facility", LogType="String", LogText="ILL")
	ws.getRun()['run_number'] = run
	ws.getRun()['run_title'] = title
	if Verbose:
		facility = ws.getRun().getLogData('facility').value
		logger.notice('Facility is ' +facility)
		runNo = ws.getRun()['run_number'].value
		runTitle = ws.getRun()['run_title'].value.strip()
		logger.notice('Run : ' +runNo + ' ; Title : ' + runTitle)
		logger.notice('Wavelength : ' + str(wave))

#  IN16B routines.
def ILLindirect(rawWS,instr,ana,refl,map,Verbose,Plot,Save):      #Ascii start routine
	StartTime('ILLindirect')
	workdir = config['defaultsave.directory']

	if Verbose:
		logger.notice('Input workspace : ' + rawWS)
	run_name = rawWS[:-4]
	rawWS = run_name +'_raw'
	idf_dir = config['instrumentDefinition.directory']
	ipf = idf_dir + instr + '_' + ana + '_' + refl + '_Parameters.xml'
	LoadParameterFile(Workspace=rawWS, Filename=ipf)
	AddSampleLog(Workspace=rawWS, LogName="facility", LogType="String", LogText="ILL")

	groupWS = run_name +'_group'
	if map == 'default':
		map_path = os.path.join(idf_dir, instr+'_groups.xml')		# path name for default map
	if map == 'user':
		map_path = os.path.join(workdir, instr+'_groups.xml')		# path name for user map
	if Verbose:
		logger.notice('Map file : '+map_path)
	GroupDetectors(InputWorkspace=rawWS, OutputWorkspace= groupWS, MapFile=map_path, 
		Behaviour='Average')

	monWS = run_name +'_mon'
	ExtractSingleSpectrum(InputWorkspace=rawWS, OutputWorkspace=monWS, WorkspaceIndex=0)

	inGR = mtd[rawWS].getRun()
	log = inGR.getLogData('mirror_sense')
	if log:
		mirror = log.value
	else:
		mirror = False
	
	if mirror == 'True':
		if Verbose:
			logger.notice('Mirror sense is ON')
		x = mtd[groupWS].readX(0)             # energy array
		mid = int((len(x)-1)/2)

		leftWS = run_name +'_left'         #left half
		lmonWS = run_name +'_left_mon'
		CropWorkspace(InputWorkspace=groupWS, OutputWorkspace=leftWS, XMax=x[mid-1])
		CropWorkspace(InputWorkspace=monWS, OutputWorkspace=lmonWS, XMax=x[mid-1])
		lredWS = run_name +'_left_red'
		CalcEenergy(lmonWS,leftWS,lredWS,Verbose)
		xl = mtd[lredWS].readX(0)
		if Verbose:
			logger.notice('Energy range, left : ' + str(xl[0]) +' to '+ str(xl[len(xl)-1]))

		rightWS = run_name +'_right'        #right half
		rmonWS = run_name +'_right_mon'        #right half
		CropWorkspace(InputWorkspace=groupWS, OutputWorkspace=rightWS, Xmin=x[mid])
		CropWorkspace(InputWorkspace=monWS, OutputWorkspace=rmonWS, Xmin=x[mid])
		x = mtd[rightWS].readX(0)
		rredWS = run_name +'_right_red'
		CalcEenergy(rmonWS,rightWS,rredWS,Verbose)
		xr = mtd[rredWS].readX(0)
		if Verbose:
			logger.notice('Energy range, right : ' + str(xr[0]) +' to '+ str(xr[len(xr)-1]))

		xl = mtd[lredWS].readX(0)
		yl = mtd[lredWS].readY(0)
		nlmax = np.argmax(np.array(yl))
		xlmax = xl[nlmax]
		xr = mtd[rredWS].readX(0)
		yr = mtd[rredWS].readY(0)
		nrmax = np.argmax(np.array(yr))
		xrmax = xr[nrmax]
		xshift = xlmax-xrmax
		ScaleX(InputWorkspace=rredWS, OutputWorkspace=rredWS, Factor=xshift, Operation='Add')
		RebinToWorkspace(WorkspaceToRebin=rredWS, WorkspaceToMatch=lredWS, OutputWorkspace=rredWS)

		sumWS = run_name +'_sum_red'          #both added
		Plus(LHSWorkspace=lredWS, RHSWorkspace=rredWS, OutputWorkspace=sumWS)
		Scale(InputWorkspace=sumWS, OutputWorkspace=sumWS, Factor=0.5, Operation='Multiply')
		plot_list = [lredWS,rredWS,sumWS]

	else:
		if Verbose:
			logger.notice('Mirror sense is OFF')
		redWS = run_name +'_red'
		CalcEenergy(monWS,groupWS,redWS,Verbose)
		plot_list = [redWS]

	if Save:
		if mirror == 'True':
			lpath = os.path.join(workdir,lredWS+'.nxs')
			SaveNexusProcessed(InputWorkspace=lredWS, Filename=lpath)
			rpath = os.path.join(workdir,rredWS+'.nxs')
			SaveNexusProcessed(InputWorkspace=rredWS, Filename=rpath)
			spath = os.path.join(workdir,sumWS+'.nxs')
			SaveNexusProcessed(InputWorkspace=sumWS, Filename=spath)
			if Verbose:
				logger.notice('Output left file : ' + lpath)
				logger.notice('Output right file : ' + rpath)
				logger.notice('Output sum file : ' + spath)
		else:
			opath = os.path.join(workdir,redWS+'.nxs')
			SaveNexusProcessed(InputWorkspace=redWS, Filename=opath)
			if Verbose:
				logger.notice('Output file : ' + opath)
	if (Plot):
		res_plot=mp.plotSpectrum(plot_list,0)

	EndTime('ILLindirect')

def CalcEenergy(monWS,groupWS,redWS,Verbose):
	xrange = MonitorRange(monWS,Verbose)
	Scale(InputWorkspace=monWS, OutputWorkspace=monWS, Factor=0.001, Operation='Multiply')
	CropWorkspace(InputWorkspace=monWS, OutputWorkspace=monWS, Xmin=xrange[0], XMax=xrange[1])
	ScaleX(InputWorkspace=monWS, OutputWorkspace=monWS, Factor=-xrange[0], Operation='Add')
	CropWorkspace(InputWorkspace=groupWS, OutputWorkspace=groupWS, Xmin=xrange[0], XMax=xrange[1])
	ScaleX(InputWorkspace=groupWS, OutputWorkspace=groupWS, Factor=-xrange[0], Operation='Add')
	Divide(LHSWorkspace=groupWS, RHSWorkspace=monWS, OutputWorkspace=groupWS)
	formula = EnergyRange(groupWS,Verbose)
	ConvertAxisByFormula(InputWorkspace=groupWS,OutputWorkspace=redWS, Axis='X', Formula=formula, 
		AxisTitle='Energy transfer', AxisUnits='meV')
	xnew = mtd[redWS].readX(0)             # energy array
	if Verbose:
		logger.notice('Energy range : ' + str(xnew[0]) +' to '+ str(xnew[len(xnew)-1]))
	DeleteWorkspace(groupWS)
	DeleteWorkspace(monWS)


def MonitorRange(monWS,Verbose):
	x = mtd[monWS].readX(0)             # energy array
	y = mtd[monWS].readY(0)             # energy array
	imin = np.argmax(np.array(y[0:20]))
	nch = len(y)
	im = np.argmax(np.array(y[nch-21:nch-1]))
	imax = nch-21+im
	if Verbose:
		logger.notice('Cropping range ' + str(x[imin]) + ' to ' + str(x[imax]))
	return x[imin],x[imax]

def EnergyRange(inWS,Verbose):
	x = mtd[inWS].readX(0)
	npt = len(x)
	imid=float(npt/2+1)
	gRun = mtd[inWS].getRun()
	wave = gRun.getLogData('wavelength').value
	freq = gRun.getLogData('Doppler.doppler_frequency').value
	amp = gRun.getLogData('Doppler.doppler_amplitude').value
	if Verbose:
		logger.notice('Wavelength : ' + str(wave))
		logger.notice('Doppler frequency : ' + str(freq))
		logger.notice('Doppler amplitude : ' + str(amp))
	vmax=1.2992581918414711e-4*freq*amp*2.0/wave 	#max energy
	dele=2.0*vmax/npt
	formula = '(x-'+str(imid)+')*'+str(dele)
	return formula
