LoadSassena(Filename='/tmp/test/fqt_inc.hd5', SortByQVectors=0, OutputWorkspace='x')
LoadSassena(Filename='/tmp/test/fqt_inc.hd5', SortByQVectors=1, OutputWorkspace='y')