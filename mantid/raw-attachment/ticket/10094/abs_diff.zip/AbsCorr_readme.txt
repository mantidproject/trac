Calc Corr

Replace sys.exit with raise ValueError
Added option to use diffraction data - using variable diffraction_run
Wavelas set to mid-value for diffraction
Added CopyLogs & SampleLogs


Apply Corr

Replace sys.exit with raise ValueError
Added option to use diffraction data - using variable diffraction_run
Added CopyLogs & SampleLogs

