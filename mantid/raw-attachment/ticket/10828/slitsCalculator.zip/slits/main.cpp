#include <QtGui/QApplication>
#include "slitscalculator.h"

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    SlitsCalculator w;
    w.show();
    
    return a.exec();
}
