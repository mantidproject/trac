#include "slitscalculator.h"
#include "ui_slitscalculator.h"
#include "qmath.h"

SlitsCalculator::SlitsCalculator(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::SlitsCalculator)
{
    ui->setupUi(this);
    recalculate();
}

SlitsCalculator::~SlitsCalculator()
{
    delete ui;
}

void SlitsCalculator::recalculate()
{
    double PI = 2*qAsin(1);
    double s1s2 = ui->s1s2->value();
    double s2sa = ui->s2sa->value();
    double res = ui->resolution->value();
    double footprint = ui->footprint->value();
    double angle = ui->angle->value();
    double s1 = 2*(s1s2+s2sa)*qTan(res*angle*PI/180) - footprint*qSin(angle*PI/180);
    double s2 = s1s2*(footprint*qSin(angle*PI/180)+s1)/(s1s2+s2sa)-s1;
    ui->lineEdit->setText(QString::number(s1,'f',3));
    ui->lineEdit_2->setText(QString::number(s2,'f',3));
}

void SlitsCalculator::onResolutionChanged()
{
    recalculate();
}
void SlitsCalculator::onFootprintChanged()
{
    recalculate();
}
void SlitsCalculator::onAngleChanged()
{
    recalculate();
}
