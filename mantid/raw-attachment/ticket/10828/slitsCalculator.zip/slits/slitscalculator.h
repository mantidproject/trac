#ifndef SLITSCALCULATOR_H
#define SLITSCALCULATOR_H

#include <QMainWindow>

namespace Ui {
class SlitsCalculator; 
}

class SlitsCalculator : public QMainWindow
{
    Q_OBJECT

public:
    explicit SlitsCalculator(QWidget *parent = 0);
    ~SlitsCalculator();

private slots:
    void onResolutionChanged();
    void onFootprintChanged();
    void onAngleChanged();
    void recalculate();

private:
    Ui::SlitsCalculator *ui;
};

#endif // SLITSCALCULATOR_H
