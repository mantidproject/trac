
large_multi_period = Load(Filename='/Users/spu92482/Desktop/multiperiod_crash/INTER00027729')
result_q, result_lam, result_theta  = ReflectometryReductionOneAuto(large_multi_period, ThetaIn=0.7)