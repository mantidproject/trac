import os

def doSortAsc(ws):
	specs = ws.getNumberHistograms()
	for i in range(0, specs):
		x = ws.readX(i)
		y = ws.readY(i)
		e = ws.readE(i)
		xrev = x[::-1]
		yrev = y[::-1]
		erev = e[::-1]
		ws.setX(i, xrev)
		ws.setY(i, yrev)
		ws.setE(i, erev)

dir = os.path.dirname(os.path.realpath(__file__))

r8481 = Load(Filename= os.path.join(dir, 'polref8481.dat'),Unit='MomentumTransfer')
r8483 = Load(Filename= os.path.join(dir, 'polref8483.dat'),Unit='MomentumTransfer')

doSortAsc(r8481)
doSortAsc(r8483)

print x.shape
print xrev.shape

x = numpy.array([3, 1, 2])
y = numpy.array([1, 2, 3])
indexes =  x.argsort()
xordered = x[indexes]
print indexes
print xordered
yordered = y[indexes]
print yordered




# Display the data to see what we're starting with 
plotSpectrum([mtd['r8481'],mtd['r8483']],0)
# Notice that the default scaling is broken when the data has 

# Now I want to rebin to the instrument resolution between the limits where I have good data in preparation for stitching.
# For r8481 this is start at 0.009 end at 0.034 step in log space with a step of 0.02
# For r8483 this is start at 0.027 end at 0.15  step in log space with a step of 0.02

Rebin(InputWorkspace='r8481',OutputWorkspace='r8481',Params='0.009,-0.02,0.034',PreserveEvents='0')
Rebin(InputWorkspace='r8483',OutputWorkspace='r8483',Params='0.027,-0.02,0.150',PreserveEvents='0')
# The result is that every y-value is 0.0