from isis_reflgui import combineMulti

import os

DataDir= os.path.expanduser('~/Desktop/Tims')
print os.path.join(DataDir, 'polref8481.dat')
r8481 = Load(Filename= os.path.join(DataDir, 'polref8481.dat'),Unit='MomentumTransfer') 
r8482 = Load(Filename= os.path.join(DataDir, 'polref8482.dat'),Unit='MomentumTransfer')
r8483 = Load(Filename= os.path.join(DataDir, 'polref8483.dat'),Unit='MomentumTransfer')
r8481 = SortXAxis(r8481)
r8482 = SortXAxis(r8482)
r8483 = SortXAxis(r8483)

Rebin(InputWorkspace='r8481',OutputWorkspace='r8481',Params='0.009,-0.02,0.034',PreserveEvents='0') 
Rebin(InputWorkspace='r8482',OutputWorkspace='r8482',Params='0.017,-0.02,0.06',PreserveEvents='0')
Rebin(InputWorkspace='r8483',OutputWorkspace='r8483',Params='0.027,-0.02,0.100',PreserveEvents='0')

ConvertToHistogram(InputWorkspace='r8481',OutputWorkspace='r8481h')
ConvertToHistogram(InputWorkspace='r8482',OutputWorkspace='r8482h')
ConvertToHistogram(InputWorkspace='r8483',OutputWorkspace='r8483h')
wcomb = combineMulti.combineDataMulti(['r8481h' , 'r8482h', 'r8483h'],'test_IvsQ',[0.009, 0.018, 0.04],[0.03, 0.046, 0.1],0.009,0.1,binning=-0.02,keep=1)