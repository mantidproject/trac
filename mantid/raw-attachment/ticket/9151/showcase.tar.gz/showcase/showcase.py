working_dir='/tmp/showcase'

w1=LoadNexus(working_dir+'/elasticLine.nxs')
print 'w1: len-X=', len(w1.dataX(0)), ' len-Y=', len(w1.dataY(0))

w2=LoadNexus(working_dir+'/Q32_sqw.nxs')
print 'w2: len-X=', len(w2.dataX(0)), ' len-Y=', len(w2.dataY(0))

wc=ConvolveWorkspaces(Workspace1=w1, Workspace2=w2)
print 'wc: len-X=', len(wc.dataX(0)), ' len-Y=', len(wc.dataY(0))
